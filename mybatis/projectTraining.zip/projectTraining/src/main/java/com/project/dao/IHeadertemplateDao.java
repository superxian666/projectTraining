package com.project.dao;

import com.project.model.headertemplate;

import java.util.List;

public interface IHeadertemplateDao {
    List<headertemplate> findHeadertemplateAll();
}
