package com.project.dao.impl;

import com.project.dao.ICollectionsDao;
import com.project.model.collections;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class CollectionsDaoImpl implements ICollectionsDao {

    private SqlSessionFactory factory;
    public CollectionsDaoImpl(SqlSessionFactory factory){
        this.factory=factory;
    }

    @Override
    public List<collections> findCollectionsAll() {
//        1、根据factory获取SqlSession对象
        SqlSession session = factory.openSession();
//        2、调用Sqlsession中的方法，实现查询列表
        List<collections> collections1=session.selectList("com.project.dao.ICollectionsDao.findCollectionsAll");
//        3、释放资源
        session.close();
        return collections1;
    }

    @Override
    public collections findByUserId(int user_id) {
        //        1、根据factory获取SqlSession对象
        SqlSession session = factory.openSession();
//        2、调用Sqlsession中的方法，实现查询列表
        collections collections2=session.selectOne("com.project.dao.ICollectionsDao.findByUserId");
//        3、释放资源
        session.close();
        return collections2;
    }

    @Override
    public collections findByCollId(String collections_id) {
        //        1、根据factory获取SqlSession对象
        SqlSession session = factory.openSession();
//        2、调用Sqlsession中的方法，实现查询列表
        collections collections3=session.selectOne("com.project.dao.ICollectionsDao.findByCollId");
//        3、释放资源
        session.close();
        return collections3;
    }

    @Override
    public void saveCollection(collections collections) {
        //        1、根据factory获取SqlSession对象
        SqlSession session = factory.openSession();
//        2、调用方法实现保存
        session.insert("com.project.dao.ICollectionsDao.saveCollection",collections);
//        3、提交事务
        session.commit();
//        4、释放资源
        session.close();
    }

    @Override
    public void updateCollection(collections collections) {
//        1、根据factory获取SqlSession对象
        SqlSession session=factory.openSession();
//        2、调用方法实现保存
        session.insert("com.project.dao.ICollectionsDao.updateCollection",collections);
//        3、提交事务
        session.commit();
//        4、释放资源
        session.close();
    }

    @Override
    public void deleteCollectionByUserId(int user_id) {
        //1.根据factory获取SqlSession对象
        SqlSession session = factory.openSession();
        //2.调用方法实现更新
        session.update("com.project.dao.ICollectionDao.deleteCollectionByUserId",user_id);
        //3.提交事务
        session.commit();
        //4.释放资源
        session.close();


    }

    @Override
    public void deleteCollectionByCollectionsId(String collections_id) {

    }

    @Override
    public int findCollTotal() {
        return 0;
    }
}
