package com.project.model;

import java.util.Date;

public class collections {
    private int user_id;
    private String collections_name;
    private String collections_id;
    private String collections_interfaces_id;
    private int success;
    private int fail;
    private String remark;
    private Date create_time;
    private Date update_time;

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getCollections_name() {
        return collections_name;
    }

    public void setCollections_name(String collections_name) {
        this.collections_name = collections_name;
    }

    public String getCollections_id() {
        return collections_id;
    }

    public void setCollections_id(String collections_id) {
        this.collections_id = collections_id;
    }

    public String getCollections_interfaces_id() {
        return collections_interfaces_id;
    }

    public void setCollections_interfaces_id(String collections_interfaces_id) {
        this.collections_interfaces_id = collections_interfaces_id;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public int getFail() {
        return fail;
    }

    public void setFail(int fail) {
        this.fail = fail;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    @Override
    public String toString() {
        return "collections{" +
                "user_id=" + user_id +
                ", collections_name='" + collections_name + '\'' +
                ", collections_id='" + collections_id + '\'' +
                ", collections_interfaces_id='" + collections_interfaces_id + '\'' +
                ", success=" + success +
                ", fail=" + fail +
                ", remark='" + remark + '\'' +
                ", create_time=" + create_time +
                ", update_time=" + update_time +
                '}';
    }
}
