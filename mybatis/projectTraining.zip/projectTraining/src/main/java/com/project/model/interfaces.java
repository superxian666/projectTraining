package com.project.model;

import java.util.Collections;

public class interfaces {
    private int user_id;
    private String collections_name;
    private String collections_id;
    private String interfaces_id;
    private String interfaces_name;
    private String interface_address;
    private String param_template;
    private String header_template;
    private String body_template;
    private String request_type;
    private String post_type;
    private String res_template;
    private String remark;
    private int create_time;
    private int update_time;

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getCollections_name() {
        return collections_name;
    }

    public void setCollections_name(String collections_name) {
        this.collections_name = collections_name;
    }

    public String getCollections_id() {
        return collections_id;
    }

    public void setCollections_id(String collections_id) {
        this.collections_id = collections_id;
    }

    public String getInterfaces_id() {
        return interfaces_id;
    }

    public void setInterfaces_id(String interfaces_id) {
        this.interfaces_id = interfaces_id;
    }

    public String getInterfaces_name() {
        return interfaces_name;
    }

    public void setInterfaces_name(String interfaces_name) {
        this.interfaces_name = interfaces_name;
    }

    public String getInterface_address() {
        return interface_address;
    }

    public void setInterface_address(String interface_address) {
        this.interface_address = interface_address;
    }

    public String getParam_template() {
        return param_template;
    }

    public void setParam_template(String param_template) {
        this.param_template = param_template;
    }

    public String getHeader_template() {
        return header_template;
    }

    public void setHeader_template(String header_template) {
        this.header_template = header_template;
    }

    public String getBody_template() {
        return body_template;
    }

    public void setBody_template(String body_template) {
        this.body_template = body_template;
    }

    public String getRequest_type() {
        return request_type;
    }

    public void setRequest_type(String request_type) {
        this.request_type = request_type;
    }

    public String getPost_type() {
        return post_type;
    }

    public void setPost_type(String post_type) {
        this.post_type = post_type;
    }

    public String getRes_template() {
        return res_template;
    }

    public void setRes_template(String res_template) {
        this.res_template = res_template;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getCreate_time() {
        return create_time;
    }

    public void setCreate_time(int create_time) {
        this.create_time = create_time;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    @Override
    public String toString() {
        return "interfaces{" +
                "user_id=" + user_id +
                ", collections_name='" + collections_name + '\'' +
                ", collections_id='" + collections_id + '\'' +
                ", interfaces_id='" + interfaces_id + '\'' +
                ", interfaces_name='" + interfaces_name + '\'' +
                ", interface_address='" + interface_address + '\'' +
                ", param_template='" + param_template + '\'' +
                ", header_template='" + header_template + '\'' +
                ", body_template='" + body_template + '\'' +
                ", request_type='" + request_type + '\'' +
                ", post_type='" + post_type + '\'' +
                ", res_template='" + res_template + '\'' +
                ", remark='" + remark + '\'' +
                ", create_time=" + create_time +
                ", update_time=" + update_time +
                '}';
    }
}
