package com.project.dao;

import com.project.model.user;

import java.util.List;

/**
 * 用户的持久层接口
 */
public interface IUserDao {

    /**
     * 查询所有用户
     * @return
     */
    List<user> findAll();

    /**
     * 保存用户
     */
    void saveUser(user user);

    /**
     * 更新用户
     */
    void updateUser(user user);

    /**
     * 根据ID删除用户
     */
    void deleteuser(int user_id);

    /**
     * 根据ID查询用户信息
     */
    user findById(int user_id);


    /**
     * 查询总用户数
     */
    int findTotal();

}
