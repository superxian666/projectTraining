package com.project.dao;

import com.project.model.interfaces;

import java.util.List;

public interface IInterfacesDao {
    List<interfaces> findInterfacesAll();
}
