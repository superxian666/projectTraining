package com.project.dao;

import com.project.model.collections;

import java.util.List;

public interface ICollectionsDao {
    /**
     * 查询所有信息
     * @return
     */
    List<collections> findCollectionsAll();

    /**
     * 根据用户id查询信息
     * @return
     */
    collections findByUserId(int user_id);

    /**
     * 根据项目id查询信息
     * @return
     */
    collections findByCollId(String collections_id);

    /**
     * 增添项目
     */
    void saveCollection(collections collections);

    /**
     * 更新项目
     */
    void updateCollection(collections collections);


    /**
     * 根据用户id删除信息
     * @return
     */
    void deleteCollectionByUserId(int user_id);


    /**
     * 根据项目id删除信息
     * @return
     */
    void deleteCollectionByCollectionsId(String collections_id);


    /**
     * 查询项目总数
     * @return
     */
    int findCollTotal();
}
