package com.project.model;

import java.util.StringTokenizer;

public class headertemplate {
    private String cookie;
    private String token;
    private  String host;
    private String user_agent;
    private String accept;
    private String accept_encoding;
    private String connection;
    private String header_template_id;

    public String getCookie() {
        return cookie;
    }

    public void setCookie(String cookie) {
        this.cookie = cookie;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUser_agent() {
        return user_agent;
    }

    public void setUser_agent(String user_agent) {
        this.user_agent = user_agent;
    }

    public String getAccept() {
        return accept;
    }

    public void setAccept(String accept) {
        this.accept = accept;
    }

    public String getAccept_encoding() {
        return accept_encoding;
    }

    public void setAccept_encoding(String accept_encoding) {
        this.accept_encoding = accept_encoding;
    }

    public String getConnection() {
        return connection;
    }

    public void setConnection(String connection) {
        this.connection = connection;
    }

    public String getHeader_template_id() {
        return header_template_id;
    }

    public void setHeader_template_id(String header_template_id) {
        this.header_template_id = header_template_id;
    }

    @Override
    public String toString() {
        return "headertemplate{" +
                "cookie='" + cookie + '\'' +
                ", token='" + token + '\'' +
                ", host='" + host + '\'' +
                ", user_agent='" + user_agent + '\'' +
                ", accept='" + accept + '\'' +
                ", accept_encoding='" + accept_encoding + '\'' +
                ", connection='" + connection + '\'' +
                ", header_template_id='" + header_template_id + '\'' +
                '}';
    }
}
