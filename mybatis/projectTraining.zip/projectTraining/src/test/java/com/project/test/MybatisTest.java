package com.project.test;

import com.project.dao.ICollectionsDao;
import com.project.dao.IUserDao;
import com.project.dao.impl.CollectionsDaoImpl;
import com.project.dao.impl.UserDaoImpl;
import com.project.model.collections;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;
import java.util.Date;

/**
 *
 * 测试mybatis的crud操作
 */
public class MybatisTest {

    private InputStream in;
    private IUserDao userDao;
    private ICollectionsDao collectionsDao;

    @Before//用于在测试方法执行之前执行
    public void init()throws Exception{
        //1.读取配置文件，生成字节输入流
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        //2.获取SqlSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(in);
        //3.使用工厂对象，创建dao对象
        userDao = new UserDaoImpl(factory);
        collectionsDao = new CollectionsDaoImpl(factory);
    }

    @After//用于在测试方法执行之后执行
    public void destroy()throws Exception{
        //6.释放资源
        in.close();
    }

    /**
     * 测试查询所有-collections表
     */
    @Test
    public void testFindCollectionsAll(){
//        5、执行查询所有方法
        List<collections> collectiontest = collectionsDao.findCollectionsAll();
        for (collections collections : collectiontest){
            System.out.println(collections);
        }
    }

    /**
     * 根据用户id查询信息
     */
    @Test
    public void testFindByUserId(){
//        5、执行根据用户id查询信息
        collections collections=collectionsDao.findByUserId(1);
        System.out.println("根据用户id查询项目信息："+collections);
    }


    /**
     * 根据项目id查询信息
     */
    @Test
    public void testFindByCollId(){
//        5、执行根据项目id查询信息
        collections collections=collectionsDao.findByCollId("coll_id2");
        System.out.println("根据项目id查询项目信息"+collections);
    }

    /**
     * 增添项目
     */
    @Test
    public void testSaveCollection() {
//        5、执行增添项目的操作
        collections collections=new collections();
        collections.setUser_id(7);
        collections.setCollections_name("coll_name7");
        collections.setCollections_id("coll_id7");
        collections.setCollections_interfaces_id("coll_inid7");
        collections.setSuccess(12);
        collections.setFail(5);
        collections.setRemark("备注7");
        collections.setCreate_time(new Date());
        collections.setUpdate_time(new Date());

//        5、执行保存方法
        collectionsDao.saveCollection(collections);
        System.out.println("保存操作成功");
    }

    /**
     * 更新项目
     */
    @Test
    public void testUpdateCollection(){
        collections collections=new collections();
        collections.setUser_id(7);
        collections.setCollections_name("testUpdatecol-name");
        collections.setCollections_id("testUpdatecol-id");
        collections.setCollections_interfaces_id("test-id");
        collections.setSuccess(10);
        collections.setFail(4);
        collections.setRemark("testupdate");
        collections.setUpdate_time(new Date());
//        执行保存方法
        collectionsDao.updateCollection(collections);

    }


    /**
     * 根据用户id删除信息
     */
    @Test
    public void testDeleteCollectionByUserId(){
        collectionsDao.deleteCollectionByUserId(7);
    }






//    对user表进行操作
//
//    /**
//     * 测试查询所有
//     */
//    @Test
//    public void testFindAll(){
//        //5.执行查询所有方法
//        List<user> users = userDao.findAll();
//        for(user user : users){
//            System.out.println(user);
//        }
//
//    }
//
//    /**
//     * 测试保存操作
//     */
//    @Test
//    public void testSave(){
//        user user=new user();
//        user.setUser_id(5);
//        user.setUsername("superxian");
//        user.setPassword("superxian666");
//        System.out.println("保存操作之前"+user);
////        5、执行保存方法
//        userDao.saveUser(user);
//
//        System.out.println("保存操作之后"+user);
//    }
//
//    /**
//     * 测试更新操作
//     */
//
//    @Test
//    public void testUpdate(){
//        user user=new user();
//        user.setUser_id(11);
//        user.setUsername("updatetTest");
//        user.setPassword("784654");
//
////        执行保存方法
//        userDao.updateUser(user);
//    }
//
//    /**
//     * 测试删除操作
//     */
//    @Test
//    public void testDelete(){
////        5.执行删除方法
//        userDao.deleteuser(11);
//    }
//
//    /**
//     * 根据id查询用户信息
//     */
//    @Test
//    public void testFindOne(){
////        5.执行查询一个方法
//        user user=userDao.findById(4);
//        System.out.println("根据id查询用户信息"+user);
//    }
//
//    /**
//     * 测试查询总记录条数
//     *
//     */
//    @Test
//    public void testFindTotal(){
////    5.执行查询用户总数方法
//        int count=userDao.findTotal();
//        System.out.println("用户总数为：" + count);
//    }




}
